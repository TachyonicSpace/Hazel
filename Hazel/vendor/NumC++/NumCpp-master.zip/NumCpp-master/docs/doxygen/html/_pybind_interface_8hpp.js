var _pybind_interface_8hpp =
[
    [ "ReturnPolicy", "_pybind_interface_8hpp.html#a0ca16a67f36ad5d1960cd9567208ed19", [
      [ "COPY", "_pybind_interface_8hpp.html#a0ca16a67f36ad5d1960cd9567208ed19ae8606d021da140a92c7eba8d9b8af84f", null ],
      [ "REFERENCE", "_pybind_interface_8hpp.html#a0ca16a67f36ad5d1960cd9567208ed19adcd320d017d7f3c317bc8b234287bc9f", null ],
      [ "TAKE_OWNERSHIP", "_pybind_interface_8hpp.html#a0ca16a67f36ad5d1960cd9567208ed19a9419303c1fae01a65adc8d1835aa2c6d", null ]
    ] ],
    [ "nc2pybind", "_pybind_interface_8hpp.html#a36135ab669dc2e6659bb9564e402edb4", null ],
    [ "pybind2nc", "_pybind_interface_8hpp.html#a4f1f494ed8dc86610403627954600812", null ],
    [ "returnPolicyStringMap", "_pybind_interface_8hpp.html#abde82685837c3645f506b0800472ffbc", null ]
];