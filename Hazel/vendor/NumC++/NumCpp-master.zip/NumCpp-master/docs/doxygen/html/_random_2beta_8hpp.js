var _random_2beta_8hpp =
[
    [ "beta", "_random_2beta_8hpp.html#ab7de94b949521786b7bde650b1e813fa", null ],
    [ "beta", "_random_2beta_8hpp.html#a9cf5ddddc350278c76e077c67b5254ab", null ]
];