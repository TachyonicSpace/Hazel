var clip_8hpp =
[
    [ "clip", "clip_8hpp.html#af82b46f44ea7fad5bbd8ef9acf2499c3", null ],
    [ "clip", "clip_8hpp.html#a5200696e06dadf4eca2f0d7332ed4af1", null ]
];