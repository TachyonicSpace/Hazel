var _version_8hpp =
[
    [ "VERSION", "_version_8hpp.html#a8fa2b5de82ba40f346d1ba1e3ad0397a", null ]
];