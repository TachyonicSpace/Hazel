var _constants_8hpp =
[
    [ "c", "_constants_8hpp.html#ac3fc62713ed109e451648c67faab7581", null ],
    [ "DAYS_PER_WEEK", "_constants_8hpp.html#a2c11c386e1a07a17f95122fc4630cbe9", null ],
    [ "e", "_constants_8hpp.html#aebabe96d6c2be3df3d71922b399e24c7", null ],
    [ "HOURS_PER_DAY", "_constants_8hpp.html#aef903b1f40001bc712b61f5dec7de716", null ],
    [ "inf", "_constants_8hpp.html#a4649bfc00f6360ccda3b3f9316e2dc0e", null ],
    [ "j", "_constants_8hpp.html#a0e933571f05ee6af915fc327260517e9", null ],
    [ "MILLISECONDS_PER_DAY", "_constants_8hpp.html#a2838aa56f95be8020a326aa6b9ba5c68", null ],
    [ "MILLISECONDS_PER_SECOND", "_constants_8hpp.html#a4373df6d6df75334290f4240f174aeb0", null ],
    [ "MINUTES_PER_DAY", "_constants_8hpp.html#aa018ab3bca299694899f51683d5b3c0f", null ],
    [ "MINUTES_PER_HOUR", "_constants_8hpp.html#a84dfb71171d2a19b89afea89be57bc52", null ],
    [ "nan", "_constants_8hpp.html#af94758715a9a5157d7ca95ab89d390ac", null ],
    [ "pi", "_constants_8hpp.html#a2f1219a120c9cc1434486d9de75a8221", null ],
    [ "SECONDS_PER_DAY", "_constants_8hpp.html#a766ec3bf1f6fb57f586f943cea1946c3", null ],
    [ "SECONDS_PER_HOUR", "_constants_8hpp.html#ad635a54557e853e1ee098d0ead5f1902", null ],
    [ "SECONDS_PER_MINUTE", "_constants_8hpp.html#ad89620cbdf9102f40ec7c0fd52c16a5e", null ],
    [ "SECONDS_PER_WEEK", "_constants_8hpp.html#ac36cac5f19ce5f81b2acc562f247f0be", null ]
];