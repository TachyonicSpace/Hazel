var _functions_2_shape_8hpp =
[
    [ "shape", "_functions_2_shape_8hpp.html#ae2b224742bc8263190d451a44ebe5e34", null ]
];