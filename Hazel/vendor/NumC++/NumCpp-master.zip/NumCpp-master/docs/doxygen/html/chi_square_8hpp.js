var chi_square_8hpp =
[
    [ "chiSquare", "chi_square_8hpp.html#a329370aed893f0e10a8050520cf0bbd4", null ],
    [ "chiSquare", "chi_square_8hpp.html#abb480e9a17b71ea09ef0f043c081e9ff", null ]
];