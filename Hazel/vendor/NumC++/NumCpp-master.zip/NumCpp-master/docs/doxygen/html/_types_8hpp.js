var _types_8hpp =
[
    [ "int16", "_types_8hpp.html#a8f5045ed0f0a08d87fd76d7a74ac128d", null ],
    [ "int32", "_types_8hpp.html#a9386099a0fdc2bc9fb0dbfde5606584d", null ],
    [ "int64", "_types_8hpp.html#a6223a7f3b0f7886036f64276f36c921e", null ],
    [ "int8", "_types_8hpp.html#a0815baab2bc081f4250ba9cb1cf361b4", null ],
    [ "uint16", "_types_8hpp.html#a8146518cf6c6a8029c3d84a376167793", null ],
    [ "uint32", "_types_8hpp.html#af0f49663fb63332596e2e6327009d581", null ],
    [ "uint64", "_types_8hpp.html#a773f8535ba713f886e9e1b8378f6d76d", null ],
    [ "uint8", "_types_8hpp.html#a9ba5a0aa26753a185985b8273fb9062d", null ],
    [ "Axis", "_types_8hpp.html#a5edb9ac6f596ae1256faa3f5d797dc84", [
      [ "NONE", "_types_8hpp.html#a5edb9ac6f596ae1256faa3f5d797dc84ab50339a10e1de285ac99d4c3990b8693", null ],
      [ "ROW", "_types_8hpp.html#a5edb9ac6f596ae1256faa3f5d797dc84a54c1ed33c810f895d48c008d89f880b7", null ],
      [ "COL", "_types_8hpp.html#a5edb9ac6f596ae1256faa3f5d797dc84aa44a065875f5d66d41474bb9bfb0ce05", null ]
    ] ],
    [ "Endian", "_types_8hpp.html#a8dcbcb343147d09e74689ad8a2586152", [
      [ "NATIVE", "_types_8hpp.html#a8dcbcb343147d09e74689ad8a2586152af78504d96ba7177dc0c6784905ac8743", null ],
      [ "BIG", "_types_8hpp.html#a8dcbcb343147d09e74689ad8a2586152aa60c6c694491d75b439073b8cb05b139", null ],
      [ "LITTLE", "_types_8hpp.html#a8dcbcb343147d09e74689ad8a2586152a1314341b466dcb5e2c880b76414c49fe", null ]
    ] ]
];