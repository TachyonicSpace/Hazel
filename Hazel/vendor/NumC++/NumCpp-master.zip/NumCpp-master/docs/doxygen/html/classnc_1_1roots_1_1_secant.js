var classnc_1_1roots_1_1_secant =
[
    [ "Secant", "classnc_1_1roots_1_1_secant.html#af8afc48a7393e85103a9c2acc662c63b", null ],
    [ "Secant", "classnc_1_1roots_1_1_secant.html#adedf56589f2027e224d6044a071f20e3", null ],
    [ "~Secant", "classnc_1_1roots_1_1_secant.html#aa5eb3c22ecf2ef92a381b6cf54fb1f83", null ],
    [ "incrementNumberOfIterations", "classnc_1_1roots_1_1_secant.html#ad0262a1a694e734ebc154c77f010bcff", null ],
    [ "numIterations", "classnc_1_1roots_1_1_secant.html#ab3192d0f9de4b8b27b23013c65489e5a", null ],
    [ "resetNumberOfIterations", "classnc_1_1roots_1_1_secant.html#a85e79a4794bc3a6ac6bc3564956737a2", null ],
    [ "solve", "classnc_1_1roots_1_1_secant.html#a3fefb4412402aa20eeabb85145463d70", null ],
    [ "epsilon_", "classnc_1_1roots_1_1_secant.html#a5eafe219bb90f82da4ece84f012a411a", null ],
    [ "maxNumIterations_", "classnc_1_1roots_1_1_secant.html#a9b1c4ea8cf91c5308020c105293b4a02", null ],
    [ "numIterations_", "classnc_1_1roots_1_1_secant.html#a84d7f2f7412d1f54861edeacc7bc0c20", null ]
];