var conj_8hpp =
[
    [ "conj", "conj_8hpp.html#a26e9df3c46d4f782d04c8d35881aad80", null ],
    [ "conj", "conj_8hpp.html#a0387ae5584e72894ae9e690eba21e26b", null ]
];