var classnc_1_1roots_1_1_brent =
[
    [ "Brent", "classnc_1_1roots_1_1_brent.html#aecf6662d1b7128d38796cf4ab99143f4", null ],
    [ "Brent", "classnc_1_1roots_1_1_brent.html#a1e9cf8f7be13c7bbb42a073ec9eb5369", null ],
    [ "~Brent", "classnc_1_1roots_1_1_brent.html#ade76ad260d82314f284ebacf885f6884", null ],
    [ "incrementNumberOfIterations", "classnc_1_1roots_1_1_brent.html#ad0262a1a694e734ebc154c77f010bcff", null ],
    [ "numIterations", "classnc_1_1roots_1_1_brent.html#ab3192d0f9de4b8b27b23013c65489e5a", null ],
    [ "resetNumberOfIterations", "classnc_1_1roots_1_1_brent.html#a85e79a4794bc3a6ac6bc3564956737a2", null ],
    [ "solve", "classnc_1_1roots_1_1_brent.html#a3853981ca1113723006b6627d96d378b", null ],
    [ "epsilon_", "classnc_1_1roots_1_1_brent.html#a5eafe219bb90f82da4ece84f012a411a", null ],
    [ "maxNumIterations_", "classnc_1_1roots_1_1_brent.html#a9b1c4ea8cf91c5308020c105293b4a02", null ],
    [ "numIterations_", "classnc_1_1roots_1_1_brent.html#a84d7f2f7412d1f54861edeacc7bc0c20", null ]
];