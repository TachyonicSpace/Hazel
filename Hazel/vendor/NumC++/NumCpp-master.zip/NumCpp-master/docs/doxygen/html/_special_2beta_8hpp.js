var _special_2beta_8hpp =
[
    [ "beta", "_special_2beta_8hpp.html#ad2ac5c7add77e243dc39899c15ad93e6", null ],
    [ "beta", "_special_2beta_8hpp.html#a9b74f451f99338c909b7f73df6e5bff6", null ]
];