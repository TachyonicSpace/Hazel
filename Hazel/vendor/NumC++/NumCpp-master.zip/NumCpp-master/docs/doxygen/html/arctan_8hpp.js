var arctan_8hpp =
[
    [ "arctan", "arctan_8hpp.html#ac7080b26d0d4d849197ae10ce6d94a53", null ],
    [ "arctan", "arctan_8hpp.html#a0f63f816e660b0a4b3da191c8584a21a", null ]
];